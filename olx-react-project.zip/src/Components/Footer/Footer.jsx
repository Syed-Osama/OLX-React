import React from 'react'
import './footer.css'
export default function Footer() {
  return (
    <div>
        <br/>
        <br/>
        <br/>
      <div className='ads'>
        <div>
        <img src='https://www.olx.com.pk/assets/olxMobileApp.f5579f77e849b600ad60857e46165516.webp' alt='social'/>

        </div>
 <div className='social'>
    <p><b>GET YOUR APP TODAY</b></p>
    <div>
        <img width={'128px'} height={'40px'} src='https://www.olx.com.pk/assets/iconAppGallery_noinline.6092a9d739c77147c884f1f7ab3f1771.svg' alt='social'/>
        <img width={'128px'} height={'40px'} src='https://www.olx.com.pk/assets/iconGooglePlayEN_noinline.9892833785b26dd5896b7c70b089f684.svg' alt='social'/>
        <img width={'128px'} height={'40px'} src='https://www.olx.com.pk/assets/iconAppStoreEN_noinline.a731d99c8218d6faa0e83a6d038d08e8.svg' alt='social'/>

    </div>
 </div>
      </div>
      <div className='l-foot'>
      <p> <b> Free Classifieds in Pakistan   </b> . © 2006-2024 OLX</p>
      </div>
    </div>
  )
}
